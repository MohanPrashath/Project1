package com.mgsofttech.ddmods;

import com.mgsofttech.ddmods.model.ModelProduct;

import java.util.ArrayList;

public class ActivityConfig {
    public static String APP_EMAIL_ADDRESS = "ddmodshelpline@gmail.com";
    public static ArrayList<ModelProduct> modelProductList = new ArrayList<>();
    public static ArrayList<String> tempOrderProductList = new ArrayList<>();
    public static ArrayList<ModelProduct> LIST_PRODUCT_BUSSID_FREE = new ArrayList<>();
    public static ArrayList<ModelProduct> LIST_PRODUCT_BUSSID_PAID = new ArrayList<>();
    public static ArrayList<ModelProduct> LIST_PRODUCT_ETS2_FREE = new ArrayList<>();
    public static ArrayList<ModelProduct> LIST_PRODUCT_ETS2_PAID = new ArrayList<>();
}
