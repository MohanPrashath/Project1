package com.mgsofttech.ddmods;

public class BuildConfig {

    public static final String VERSION_NAME = "1.0.0";
}
