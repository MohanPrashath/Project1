package com.mgsofttech.ddmods;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class LegalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_legal);
    }
}