package com.mgsofttech.ddmods.model;

public class ModelImage {
    String image;

    public ModelImage(String str) {
        this.image = str;
    }

    public String getImage() {
        return this.image;
    }

    public void setImage(String str) {
        this.image = str;
    }
}
